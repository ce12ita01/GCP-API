import datetime
import logging
import uuid

from api_resources.upsert_attribute.upsert_calculated_attribute_dao.calculated_attri_compute import \
    find_calculated_atrri_in_db, find_employee_id_db


def add_id_to_request_values(database, upsert_dict, partial_status, Signature, Country, EmployeeId):
    """
    ADD PK ID into Keys and values for SQL Queries
    :param partial_status:
    :param EmployeeId:
    :param database:
    :param Country:
    :param Signature:
    :param upsert_dict:
    :return:
    """
    try:
        employee_in_db = find_employee_id_db(database, Signature, Country, EmployeeId)
        logging.info("employee in DB", employee_in_db)
        if len(employee_in_db) > 0:
            for employee_pk_id in employee_in_db:
                employee_pk_value = employee_pk_id[0]
        else:
            employee_pk_value = None
        upsert_dict['employee_Key'] = employee_pk_value

        # Check if record in db
        record_in_db, db_status = find_employee_atrri_in_db(database, upsert_dict)
        partial_status = get_status(partial_status, record_in_db, upsert_dict)
        return upsert_dict, partial_status, db_status
    except Exception:
        return upsert_dict, partial_status, db_status


def get_status(partial_status, record_in_db, upsert_dict):
    Sys_Create_Timestamp = datetime.datetime.now(datetime.timezone.utc)
    if len(record_in_db) == 0:
        upsert_dict['Sys_Create_Timestamp'] = Sys_Create_Timestamp
        upsert_dict['Sys_Update_Timestamp'] = Sys_Create_Timestamp
        pk_value = (str(uuid.uuid4()))
    else:
        for pk_id in record_in_db:
            upsert_dict['Sys_Create_Timestamp'] = record_in_db[0][1]
            upsert_dict['Sys_Update_Timestamp'] = Sys_Create_Timestamp
            pk_value = pk_id[0]
            partial_status = True
    upsert_dict['Employee_Attribute_Pk_Id'] = pk_value
    return partial_status
