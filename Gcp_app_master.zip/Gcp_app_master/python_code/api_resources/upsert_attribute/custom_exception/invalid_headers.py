# class InvalidHeader is derived from super class Exception
class InvalidHeader(Exception):
    pass


# No Records to upsert/Body Missing
class NoRecordsException(Exception):
    pass


# No Valid  Records to upsert
class NoValidRecords(Exception):
    pass
