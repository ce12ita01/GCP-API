from google.cloud import spanner


def find_employee_atrri_in_db(database, calculated_atrri_record):
    try:
        with database.snapshot() as snapshot:
            results = snapshot.execute_sql("SELECT Employee_Attribute_Pk_Id,Sys_Create_Timestamp FROM TW_EMPLOYEE_ATTRIBUTES_TBL "
                                           "WHERE Name = @Name  and Employee_Key=@Employee_Key",
                                           params={"Name": calculated_atrri_record.get('Name'),
                                                   "Employee_Key": calculated_atrri_record.get('Employee_Key')},
                                           param_types={"Name": spanner.param_types.STRING,
                                                        "Employee_Key": spanner.param_types.STRING},
                                           )
        return list(results), True
    except Exception:
        return calculated_atrri_record, False



def find_employee_id_db(database, Signature, Country, EmployeeId):
    try:
        with database.snapshot() as snapshot:
            results = snapshot.execute_sql("SELECT EmployeeId FROM TW_CONSUMER_INFO_TBL "
                                           "WHERE Signature =@Signature and HashedCountry = @Country and EmployeeId=@EmployeeId",
                                           params={"Signature": Signature,
                                                   "Country": Country,
                                                   "EmployeeId": EmployeeId},
                                           param_types={"Signature": spanner.param_types.STRING,
                                                        "Country": spanner.param_types.STRING,
                                                        "EmployeeId": spanner.param_types.STRING},
                                           )
        return results
    except Exception as e:
        raise e
