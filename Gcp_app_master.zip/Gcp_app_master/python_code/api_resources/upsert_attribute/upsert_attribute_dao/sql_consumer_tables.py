from data_model.spanner_tables_list import error_tbl


def upsert_spanner_tbl(database, upsert_dict_keys, upsert_dict_values, table_name):
    try:
        with database.batch() as batch:
            batch.insert_or_update(
                table_name,
                columns=tuple(upsert_dict_keys),
                values=upsert_dict_values
            )
        return True
    except Exception:
        return False


def insert_error_tbl(database, transaction_id, error_records, error_message, table_name=error_tbl):
    values = [(str(transaction_id), str(error_records), str(error_message))]
    try:
        def insert_error(transaction):
            sql = "INSERT {} (Transaction_ID, Error_Records, Error_Message) VALUES {}".format(table_name, values[0])
            row_ct = transaction.execute_update(sql)
            print("{} record(s) inserted.".format(row_ct))

        database.run_in_transaction(insert_error)
        return True
    except Exception:
        return False
