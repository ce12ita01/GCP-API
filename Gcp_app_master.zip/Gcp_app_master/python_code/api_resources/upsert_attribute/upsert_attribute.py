import json
import logging
import os
import hashlib
from google.cloud import spanner
from flask import Blueprint
from flask import request, jsonify

from python_code.api_resources.upsert_attribute.custom_exception.invalid_headers import NoRecordsException, \
    InvalidHeader, NoValidRecords
from python_code.api_resources.upsert_attribute.upsert_attribute_dao.employee_attri_compute import \
    find_EmployeeId_in_id
from python_code.api_resources.upsert_attribute.upsert_attribute_service.uuid_compute import \
    add_id_to_request_values
from python_code.data_model.spanner_tables_list import employee_attribute_tbl
from python_code.api_resources.upsert_attribute.upsert_attribute_dao.sql_consumer_tables import \
    upsert_spanner_tbl, insert_error_tbl
from python_code.data_model.table_mapping import tw_attributes_table


os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "apmena-cdps-dv-abd681ecaa6d.json"
global Transaction_id

attri_bp = Blueprint('employee_attri', __name__)

errors = Blueprint('errors', __name__)

instance_id = os.environ.get("instance_id")
database_id = os.environ.get("database_id")
project_id = os.environ.get("project_id")
topic_id = os.environ.get("topic_id")


@errors.app_errorhandler(Exception)
@employee_attri_bp.route('/v1.0/upsertattributes/<EmployeeId>', methods=['POST'])
def create(EmployeeId):
    """
        :param EmployeeId:
    """
    try:
        # Initialize the spanner client
        spanner_client = spanner.Client()
        instance = spanner_client.instance(instance_id)
        database = instance.database(database_id)

        Transaction_id = request.headers.get('TransactionId')
        Signature = request.headers.get('Signature')
        Country = return_sha_hex(request.headers.get('ISOCountry'))

        Country, Signature, Transaction_id = validate_headers(Country, Signature, Transaction_id)

        EmployeeId = find_EmployeeId_in_id(database, Signature, Country, EmployeeId)
        if len(list(EmployeeId)) == 0:
            response_body = {"TransactionId": Transaction_id, "Message": "EmployeeId not found in db", "Code": 900}
            status_code = 400
            return jsonify(response_body), status_code

        raw_employee_atrri_obj = get_request_body(Transaction_id, request.data)

        Name, employee_atrri_obj, error_records = get_valid_employee_atrri_records(raw_employee_atrri_obj,
                                                                                       database, Transaction_id)

        employee_atrri_obj_keys, employee_atrri_upsert_values, partial_status = get_upsert_keys_values(
            employee_atrri_obj, database, Signature, Country, EmployeeId)

        if len(error_records) > 0:
            insert_error_table(database, error_records, Transaction_id, "Madatory fields are missing in any Records")

        # Upsert in Employee Master Table
        logging.info("Upserting the Employee Attribute records.")

        # Add to Spanner table
        upsert_status = upsert_spanner_tbl(database, employee_atrri_obj_keys, employee_atrri_upsert_values,
                                           employee_attribute_tbl)
        if not upsert_status:
            insert_error_table(database, employee_atrri_obj, Transaction_id,
                               "Employee Attri record failed for Backend issue please check datatype")
            response_body = {"TransactionId": Transaction_id, "Message": "DB upsert failed", "Code": 500}
            status_code = 500
            return jsonify(response_body), status_code

        response_body, status_code = generate_response_codes(Name, employee_atrri_obj, partial_status,
                                                             raw_employee_atrri_obj, Transaction_id, error_records)
        return jsonify(response_body), status_code

    except InvalidHeader as e:
        return jsonify(e.args[0]), 400
    except NoRecordsException as e:
        return jsonify(e.args[0]), 400
    except NoValidRecords as e:
        return jsonify(e.args[0]), 400
    except Exception:
        response_body = {"transaction_id": Transaction_id, "message": "URL not available/ Not found", "code": 901}
        return jsonify(response_body), 404


def validate_headers(Country, Signature, Transaction_id):
    # Retrieve the request headers, optional args and request body if passed
    if (Country is None) or (Country == '') or (Signature is None) or (Signature == '') or \
            (Transaction_id is None) or (Transaction_id == ''):
        response_body = {"transaction_id": Transaction_id,
                         "message": "Required headers missing ", "code": 900}
        raise InvalidHeader(response_body)
    else:
        return Country, Signature, Transaction_id


def get_request_body(Transaction_id, data):
    if data:
        request_body = json.loads(data)
        raw_employee_atrri_obj = request_body["EmployeeAttributes"]

    if len(data) == 0 or len(raw_employee_atrri_obj) == 0:
        response_body = {"transactionId": Transaction_id, "message": "No Records to upsert/Body Missing", "code": 900}
        raise NoRecordsException(response_body)
    return raw_employee_atrri_obj


def get_valid_employee_atrri_records(raw_employee_atrri_obj, database, Transaction_id):
    # Check if the request body keys exist in entity
    employee_atrri_obj = []
    error_records = []
    Name = raw_employee_atrri_obj[0].get('Name')
    for record in raw_employee_atrri_obj:
        if record.get('Name') and record.get('EmployeeId'):
            employee_atrri_dict = dict.fromkeys(tw_attributes_table, None)
            for col in tw_attributes_table:
                employee_atrri_dict[col] = record.get(col)
            employee_atrri_obj.append(employee_atrri_dict)
        else:
            error_records.append(record)
    if len(employee_atrri_obj) == 0:
        # Insertion into Error Table
        logging.info("Insert into Error Table")
        insert_error_table(database, error_records, Transaction_id,
                           "Failed Employee Attri Records/Madatory Fields missing in Record")
        response_body = {"transactionId": Transaction_id, "message": "No valid Records to upsert", "code": 900}
        raise NoValidRecords(response_body)
    return Name, employee_atrri_obj, error_records


def get_upsert_keys_values(employee_atrri_obj, database, Signature, Country, EmployeeId):
    # Get valid record attribute values
    employee_atrri_obj_keys = list(employee_atrri_obj[0].keys())
    employee_atrri_obj_keys.extend(['Employee_Key', 'employee_Attribute_Pk_Id'])
    employee_atrri_upsert_values = []
    partial_status = False
    for obj in employee_atrri_obj:
        obj_upsert_values, partial_status, id_status = add_id_to_request_values(database, obj, partial_status,
                                                                                Signature, Country, EmployeeId)
        if not id_status:
            employee_atrri_obj.remove(obj)
        employee_atrri_upsert_dict_values = obj_upsert_values.values()
        employee_atrri_upsert_values.append(tuple(employee_atrri_upsert_dict_values))
    return employee_atrri_obj_keys, employee_atrri_upsert_values, partial_status


def generate_response_codes(Name, employee_atrri_obj, partial_status, raw_employee_atrri_obj, Transaction_id,
                            error_records):

    if len(raw_employee_atrri_obj) == len(employee_atrri_obj) and partial_status is True and len(
            error_records) == 0:
        response_body = {"transactionId": Transaction_id, "Name": Name, "status": "Insert/Upsert Completed."}
        status_code = 200
    elif partial_status is False:
        response_body = {"transactionId": Transaction_id, "Name": Name, "status": "New Records insert only.",  "error_record": error_records}
        status_code = 201
    else:
        response_body = {"transactionId": Transaction_id, "Name": Name, "status": "Partial Upsert.",
                         "error_record": error_records}
        status_code = 202
    return response_body, status_code


def insert_error_table(database, error_records, Transaction_id, error_message):
    # Insertion into Error Table
    logging.info("Insert into Error Table")
    insert_error_tbl(database, Transaction_id, error_records, error_message)


def return_sha_hex(string):
    """
    :param string:
    :return SHA256 hashed string:
    """
    if string is None:
        return None
    return hashlib.sha256(str(string).encode('utf-8')).hexdigest()
