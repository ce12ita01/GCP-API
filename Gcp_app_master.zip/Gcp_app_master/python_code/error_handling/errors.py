"""
Application error handlers.
"""
from flask import Blueprint, jsonify, current_app, request

errors = Blueprint('errors', __name__)

@errors.app_errorhandler(Exception)
def handle_unexpected_error(error):
    transaction_id = request.headers.get('TransactionId')
    current_app.preprocess_request()
    message = "Internal Server Error"
    status_code = 500
    response = {
        'transaction_id': transaction_id,
        'status': status_code,
        'message': message
        }
    print(response)
    return jsonify(response), status_code
