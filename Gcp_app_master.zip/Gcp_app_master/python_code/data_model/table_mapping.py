tw_error_table = ['Transaction_ID', 'Error_Records', 'Error_Message']

tw_employee_attribute_table = ['Name', 'EmployeeId']
