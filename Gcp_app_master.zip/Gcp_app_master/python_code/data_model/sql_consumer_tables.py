import logging

from google.cloud import spanner

from python_code.data_model.spanner_tables_list import error_tbl


def upsert_spanner_tbl(database, upsert_dict_keys, upsert_dict_values, table_name):
    try:
        with database.batch() as batch:
            batch.insert_or_update(
                table_name,
                columns=tuple(upsert_dict_keys),
                values=upsert_dict_values
            )
        return True
    except Exception as e:
        return False


def insert_error_tbl(database, transaction_id, error_records, error_message, table_name=error_tbl):
    values = [(str(transaction_id), str(error_records), str(error_message))]
    try:
        def insert_error(transaction):
            sql = "INSERT {} (Transaction_ID, Error_Records, Error_Message) VALUES {}".format(table_name, values[0])
            row_ct = transaction.execute_update(sql)
            print("{} record(s) inserted.".format(row_ct))
        database.run_in_transaction(insert_error)
        return True
    except Exception as e:
        return False


def find_consumer_id_in_db(database, lucid, signature, country):
    """
    :param: database credentials
    :param: header params
    """
    try:
        with database.snapshot() as snapshot:
            pk_id = snapshot.execute_sql("SELECT Consumer_Id FROM TW_CONSUMER_INFO_TBL "
                                         "WHERE Lucid = @Lucid and Signature = @Signature and Country = @Country",
                                         params={"Lucid": lucid,
                                                 "Signature": signature,
                                                 "Country": country},
                                         param_types={"Lucid": spanner.param_types.STRING,
                                                      "Signature": spanner.param_types.STRING,
                                                      "Country": spanner.param_types.STRING}, )
        return list(pk_id)

    except Exception as e:
        response_body = {"message": "DB extraction failed", 'code': 400}
        raise e
