from flask import Flask

from error_handling.errors import errors
from python_code.api_resources.upsert_attribute.upsert_attribute import attri_bp

app = Flask(__name__)

app.config['JSONIFY_PRETTYPRINT_REGULAR'] = False
app.config['JSON_AS_ASCII'] = False


def _initialize_errorhandlers(application):
    '''
    Initialize error handlers
    '''
    application.register_blueprint(errors)


_initialize_errorhandlers(app)
app.register_blueprint(attri_bp, url_prefix='/Employee')

if __name__ == '__main__':
    app.run()
    #app.run(debug=True, port=8080, host='0.0.0.0')
