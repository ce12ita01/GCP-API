from cryptography.fernet import Fernet
def encrypt_data(string):
    """
    Encrypt Data
    :param key:
    :param string:
    :return Encrypted String:
    """
    key = b'psKy5q0Qa0qCGmj8qO9WoqdcjiKDIuJtc='
    if string is None:
        return None
    f = Fernet(key)
    return f.encrypt(str(string).encode())
print(encrypt_data("ABCD"))
print(encrypt_data("ABCD"))
print(encrypt_data("ABCD"))